library(testthat)
library(GpGp)

test_check("GpGp")
