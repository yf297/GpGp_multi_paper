
devtools::load_all("..")

n <- 4
p <- 2
locs <- matrix( runif(2*n), n, 2 )
locs <- rbind(locs,locs)
locs_comp <- cbind( locs, rep(1:p,each=n) )

covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,0.005,1.01)
covparms <- c(1,0.0,1,  0.5,0.5,0.5,  0.5,0.5,0.5,  0.01,1.01)
covparms <- c(1,0.5,1,0.5,0.5,1,  0.5,0.4,0.6,0.4,0.4,0.7,  0.5,0.5,0.5,0.5,0.5,0.5,  0.01,1.01,2.01)

covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)

covparms <- c(2.3450427,   0.9267297,  35.8331441,   1.3987869,  0.9919181,   1.2865249,
0.6609239, 1.5670564,   0.7285530,   0.1476378,   0.1765554)
covparms <- c(2.3589, 1, 39.1426, 1.6126, 1.2141, 1.504, 0.8, 0.8, 0.8, 0.1786, 0.216)   

M <- matern_multi( covparms, locs_comp )
C <- t(chol(M))
C

# check derivative of covariances
devtools::load_all()
m <- nrow(locs_comp)
nparms <- length(covparms)
covmat <- matern_multi( covparms, locs_comp )
dcovmat <- d_matern_multi( covparms,locs_comp )
ddcov <- array(NA, c(m,m,nparms) )
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    cov <- matern_multi( dcovparms, locs_comp )
    ddcov[,,k] <- (cov - covmat)/eps
    print( range( dcovmat[,,k] - ddcov[,,k] ) )
}

# check derivative of spectra
devtools::load_all()
covparms <- c(1,4,2.5)
omega1 <- seq(0,4/(2*pi*covparms[2]),length.out = 40)
omega2 <- seq(0,4/(2*pi*covparms[2]),length.out = 40)
omega <- expand.grid( omega1, omega2 )
spec <- matern_spectrum( covparms, omega )
nparms <- length(covparms)
d_spec <- d_matern_spectrum( covparms, omega )
d_spec_eps <- array(NA, dim(d_spec))
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    spec_eps <- matern_spectrum( dcovparms, omega )
    d_spec_eps[,k] <- (spec_eps - spec)/eps
    print( range( d_spec[,k] - d_spec_eps[,k] ) )
}

# check second derivative of spectra
devtools::load_all()
covparms <- c(1,4,0.5)
omega1 <- seq(0,4/(2*pi*covparms[2]),length.out = 40)
omega2 <- seq(0,4/(2*pi*covparms[2]),length.out = 40)
omega <- expand.grid( omega1, omega2 )
d_spec <- d_matern_spectrum( covparms, omega )
nparms <- length(covparms)
dd_spec <- dd_matern_spectrum( covparms, omega )
dd_spec_eps <- array(NA, dim(dd_spec))
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    d_spec_eps <- d_matern_spectrum( dcovparms, omega )
    dd_spec_eps[,,k] <- (d_spec_eps - d_spec)/eps
    print( range( d_spec[,k] - d_spec_eps[,k] ) )
}

# check derivative of cross spectra
devtools::load_all()
#covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
effrange <- 1
cross_spec <- matern_cross_spectra( covparms, effrange )
nparms <- length(covparms)
d_cross_spec <- d_matern_cross_spectra( covparms, effrange )
d_cross_spec_eps <- array(NA, dim(d_cross_spec) )
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    cross_spec_eps <- matern_cross_spectra( dcovparms, effrange )
    d_cross_spec_eps[,,,k] <- (cross_spec_eps - cross_spec)/eps
    print( range( d_cross_spec[,,,k] - d_cross_spec_eps[,,,k] ) )
}

# check derivative of marginal-cross spectra
devtools::load_all()
covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
#covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
effrange <- 1
cross_spec <- matern_marg_spectra2( covparms, effrange )
nparms <- length(covparms)
d_cross_spec <- d_matern_marg_spectra2( covparms, effrange )
d_cross_spec_eps <- array(NA, dim(d_cross_spec) )
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    cross_spec_eps <- matern_marg_spectra2( dcovparms, effrange )
    d_cross_spec_eps[,,,k] <- (cross_spec_eps - cross_spec)/eps
    print( range( d_cross_spec[,,,k] - d_cross_spec_eps[,,,k] ) )
}

# check second derivative of cross spectra
devtools::load_all()
#covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
effrange <- 1
d_cross_spec <- d_matern_cross_spectra( covparms, effrange )
dd_cross_spec <- dd_matern_cross_spectra( covparms, effrange )
nparms <- length(covparms)
dd_cross_spec_eps <- array(NA, dim(dd_cross_spec) )
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    d_cross_spec_eps <- d_matern_cross_spectra( dcovparms, effrange )
    dd_cross_spec_eps[,,,,k] <- (d_cross_spec_eps - d_cross_spec)/eps
    print( range( dd_cross_spec[,,,,k] - dd_cross_spec_eps[,,,,k] ) )
}

# check second derivative of marginal-cross spectra
devtools::load_all()
covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
#covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
effrange <- 1
d_cross_spec <- d_matern_marg_spectra2( covparms, effrange )
dd_cross_spec <- dd_matern_marg_spectra2( covparms, effrange )
nparms <- length(covparms)
dd_cross_spec_eps <- array(NA, dim(dd_cross_spec) )
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    d_cross_spec_eps <- d_matern_marg_spectra2( dcovparms, effrange )
    dd_cross_spec_eps[,,,,k] <- (d_cross_spec_eps - d_cross_spec)/eps
    print( range( dd_cross_spec[,,,,k] - dd_cross_spec_eps[,,,,k] ) )
}

# check the derivative of the cross inverse penalty
devtools::load_all("..")
effrange <- 1
covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
pen <- pen_traceinv_cross_spec( covparms, effrange ) 
dpen1 <- dpen_traceinv_cross_spec( covparms, effrange )
dpen2 <- rep(NA, nparms)
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newpen <- pen_traceinv_cross_spec( dcovparms, effrange )
    dpen2[k] <- (newpen - pen)/eps
}
print( cbind(dpen1,dpen2,dpen1-dpen2) )

# check the derivative of the cross penalty
devtools::load_all()
effrange <- 1
#covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
pen <- pen_logdet_cross_spec( covparms, effrange ) 
dpen1 <- dpen_logdet_cross_spec( covparms, effrange )
dpen2 <- rep(NA, nparms)
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newpen <- pen_logdet_cross_spec( dcovparms, effrange )
    dpen2[k] <- (newpen - pen)/eps
}
print( cbind(dpen1,dpen2,dpen1-dpen2) )

# check the derivative of the marginal penalty
devtools::load_all()
effrange <- 1
#covparms <- c(1,0.5,1,  0.5,0.4,0.6,  0.5,0.5,0.5,  0.01,1.01)
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
pen <- pen_logvar_marg_spec( covparms, effrange ) 
dpen1 <- dpen_logvar_marg_spec( covparms, effrange )
dpen2 <- rep(NA, nparms)
eps <- 1e-8
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newpen <- pen_logvar_marg_spec( dcovparms, effrange )
    dpen2[k] <- (newpen - pen)/eps
}
print( cbind(dpen1,dpen2,dpen1-dpen2) )



# check the second derivative of the cross penalty
effrange <- 1
dpen <- dpen_logdet_cross_spec( covparms, effrange ) 
ddpen1 <- ddpen_logdet_cross_spec( covparms, effrange )
ddpen2 <- matrix(NA, nparms, nparms)
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newdpen <- dpen_logdet_cross_spec( dcovparms, effrange )
    ddpen2[,k] <- (newdpen - dpen)/eps
}
print( ddpen1 )
print( ddpen2 )
print( (ddpen1 - ddpen2)/abs(ddpen1) )

# check the second derivative of the inverse cross penalty
devtools::load_all()
effrange <- 1
dpen <- dpen_traceinv_cross_spec( covparms, effrange ) 
ddpen1 <- ddpen_traceinv_cross_spec( covparms, effrange )
ddpen2 <- matrix(NA, nparms, nparms)
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newdpen <- dpen_traceinv_cross_spec( dcovparms, effrange )
    ddpen2[,k] <- (newdpen - dpen)/eps
}
print( ddpen1 )
print( ddpen2 )
print( round( (ddpen1 - ddpen2), 6 ) )
print( round( (ddpen1 - ddpen2)/abs(ddpen1), 6 ) )



# check the second derivative of the marginal penalty
effrange <- 1
dpen <- dpen_logvar_marg_spec( covparms, effrange ) 
ddpen1 <- ddpen_logvar_marg_spec( covparms, effrange )
ddpen2 <- matrix(NA, nparms, nparms)
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newdpen <- dpen_logvar_marg_spec( dcovparms, effrange )
    ddpen2[,k] <- (newdpen - dpen)/eps
}
print( ddpen1 )
print( ddpen2 )
print( (ddpen1 - ddpen2)/abs(ddpen1) )


# check the derivative of the marginal variance penalty
devtools::load_all()
effrange <- 5
pen <- pen_logvar_marg_spec( covparms, effrange ) 
dpen1 <- dpen_logvar_marg_spec( covparms, effrange )
dpen2 <- rep(NA, nparms)
for(k in 1:nparms){
    dcovparms <- covparms
    dcovparms[k] <- covparms[k] + eps
    newpen <- pen_logvar_marg_spec( dcovparms, effrange )
    dpen2[k] <- (newpen - pen)/eps
}
print( (dpen1 - dpen2)/abs(dpen1) )

ddpen <- ddpen_logvar_marg_spec( covparms, effrange )
pen <- pen_logvar_marg_spec( covparms, effrange )
print(pen)

# check the information matrix
m <- nrow(locs_comp)
y <- rep(0,m) 
nparms <- length(covparms)
covmat <- matern_multi( covparms, locs_comp )
dcovmat <- d_matern_multi( covparms,locs_comp )
NNarray <- find_ordered_nn( locs_comp, 8 )
X <- matrix(1, m, 1 )
vecch <- vecchia_profbeta_loglik_grad_info( covparms, "matern_multi", y, X, locs_comp, NNarray )
gr <- rep(NA,nparms)
info <- matrix(NA,nparms,nparms)
for(j1 in 1:nparms){
    M1 <- solve( covmat, dcovmat[,,j1])
    gr[j1] <- -1/2*sum(diag( M1 ) )
    for(j2 in 1:nparms){
        M2 <- solve( covmat, dcovmat[,,j2])
        info[j1,j2] <- 1/2*sum( diag(M1 %*% M2) )
    }
}
range( gr - vecch$gr )
range( info - vecch$info )
    
info <- 1/2*sum( diag( M%*%M) )

vecch2 <- vecchia_profbeta_loglik_grad_info(
    covparms[c(1,4,7,10)], "matern_isotropic",
    y[1:4], X[1:4,,drop=FALSE], locs_comp[1:4,1:2], NNarray[1:4,1:5] )



devtools::load_all("..")
effrange <- 0.01
pen <- function(x){
    pen_logvar_marg_spec(x,effrange) - pen_logdet_cross_spec(x,effrange)
}
dpen <- function(x){
    dpen_logvar_marg_spec(x,effrange) - dpen_logdet_cross_spec(x,effrange)
}
ddpen <- function(x){
    ddpen_logvar_marg_spec(x,effrange) - ddpen_logdet_cross_spec(x,effrange)
}
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2))
for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ) ) } }
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
t(chol(ddp))



effrange <- 0.03
pen <- function(x){
    ( pen_logvar_marg_spec(x,effrange) - pen_logdet_cross_spec(x,effrange) )^2
}
dpen <- function(x){
    sqp <- pen_logvar_marg_spec(x,effrange) - pen_logdet_cross_spec(x,effrange)
    dsqp <- dpen_logvar_marg_spec(x,effrange) - dpen_logdet_cross_spec(x,effrange)
    return( 2*sqp*dsqp )
}
ddpen <- function(x){
    sqp <- pen_logvar_marg_spec(x,effrange) - pen_logdet_cross_spec(x,effrange)
    dsqp <- dpen_logvar_marg_spec(x,effrange) - dpen_logdet_cross_spec(x,effrange)
    ddsqp <- ddpen_logvar_marg_spec(x,effrange) - ddpen_logdet_cross_spec(x,effrange)
    return( 2*outer(dsqp,dsqp) + 2*sqp*ddsqp )
}
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2))
for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ) ) } }
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
t(chol(ddp))



y <- dpen(covparms)
z <- rep(NA, length(covparms))
eps <- 1e-8
for(j in 1:length(covparms)){
    x <- covparms
    dx <- x
    dx[j] <- dx[j]+eps
    z[j] <- (pen(dx)-pen(x))/eps
}
print( cbind(y,z,y-z) )



y <- ddpen(covparms)
z <- matrix(NA, length(covparms), length(covparms))
eps <- 1e-8
for(j in 1:length(covparms)){
    x <- covparms
    dx <- x
    dx[j] <- dx[j]+eps
    z[,j] <- (dpen(dx)-dpen(x))/eps
}
print( cbind(y,z,y-z) )



devtools::load_all("..")
effrange <- 0.1
pen <- function(x){
    - pen_logdet_cross_spec(x,effrange)
}
dpen <- function(x){
    - dpen_logdet_cross_spec(x,effrange)
}
ddpen <- function(x){
    - ddpen_logdet_cross_spec(x,effrange)
}
covparms <- c(0.9132,0.488,1.0431,0.02,0.0297,0.0334,0.6434,0.9,1.3468,0.001,0)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2))
for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ) ) } }
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
t(chol(ddp))



devtools::load_all("..")
effrange <- 0.1
pen <- function(x){
    -pen_logvar_marg_spec(x,effrange)
}
dpen <- function(x){
    -dpen_logvar_marg_spec(x,effrange)
}
ddpen <- function(x){
    -ddpen_logvar_marg_spec(x,effrange)
}
covparms <- c(0.9132,0.488,1.0431,0.02,0.0297,0.0334,0.6434,0.9,1.3468,0.001,0)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2))
for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ) ) } }
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
t(chol(ddp))



devtools::load_all("..")
effrange <- 0.1
pen <- function(x){
    -pen_logvar_marg_spec(x,effrange) - pen_logdet_cross_spec(x,effrange)
}
dpen <- function(x){
    -dpen_logvar_marg_spec(x,effrange) - dpen_logdet_cross_spec(x,effrange)
}
ddpen <- function(x){
    -ddpen_logvar_marg_spec(x,effrange) - ddpen_logdet_cross_spec(x,effrange)
}
covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2))
for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ) ) } }
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
t(chol(ddp))


devtools::load_all("..")
effrange <- 100.0
pen <- function(x){
    pen_logvar_marg_spec(x,effrange) -
    pen_logdet_cross_spec(x,effrange) +
    pen_traceinv_cross_spec(x,effrange)
}
dpen <- function(x){
    dpen_logvar_marg_spec(x,effrange) -
    dpen_logdet_cross_spec(x,effrange) +
    dpen_traceinv_cross_spec(x,effrange)
}
ddpen <- function(x){
    ddpen_logvar_marg_spec(x,effrange) -
    ddpen_logdet_cross_spec(x,effrange) +
    ddpen_traceinv_cross_spec(x,effrange)
}
#covparms <- c(0.9132,0.488,1.0431,0.0269,0.0297,0.0334,0.6434,0.9951,1.3468,0.001,0)
covparms <- c(1,0.9,1,  0.5,0.5,0.5,  0.5,0.5,0.5,  0.01,1.01)
ncomp <- 2
cm <- matern_cross_spectra(covparms,effrange)
par(mfrow=c(2,2)); for(j1 in 1:ncomp){ for(j2 in 1:ncomp){ implot( matrix( cm[,j1,j2], 40, 40 ))}}
p <- pen(covparms)
dp <- dpen(covparms)
ddp <- ddpen(covparms)
ddp[1:3,1:3]
eigen(ddp[1:3,1:3])
t(chol(ddp))


