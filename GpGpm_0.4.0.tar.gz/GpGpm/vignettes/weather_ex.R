load("../data/weather.RData")
library(magic)
devtools::load_all("..")

y_mat <- weather[,c(4,5)]
y1 <- matrix(y_mat[,1])
y2 <- matrix(y_mat[,2])          
locs0 <- weather[,c(1,2,3)]

X1 <- as.matrix(rep(1, length(y1)))
X2 <- as.matrix(rep(1, length(y2))) 

X <- adiag(X1, X1)
y <- as.vector(y_mat)

locs <- rbind(cbind(locs0, 1), cbind(locs0, 2))

fit <- fit_model(y, locs, X, "matern_multi")
