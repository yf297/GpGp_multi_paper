data <- as.matrix(read.csv("../data/3a_1_train.csv"))
data <- data[sample(500),]
library(magic)
devtools::load_all("..")

y_mat <- data[,c(3,4)]
y1 <- matrix(y_mat[,1])
y2 <- matrix(y_mat[,2])          
locs0 <- data[,c(1,2)]

X1 <- as.matrix(rep(1, length(y1)))
X2 <- as.matrix(rep(1, length(y2))) 

X <- adiag(X1, X1)
y <- as.vector(y_mat)

locs1 <- cbind(locs0, 1)
locs2 <- cbind(locs0, 2)
names(locs1) <- names(locs2) <- c("x", "y", "comp")
locs <- rbind(locs1, locs2)

NNarray <- nearest_multi_any(locs, 30)	
fit_model(y, locs, X, covfun_name = "matern_multi", NNarray, reorder = F)


