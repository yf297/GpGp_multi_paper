
#ifndef CROSSMATRIX_FUNS_01_H
#define CROSSMATRIX_FUNS_01_H

// covariance functions
#include <RcppArmadillo.h>
#include <iostream>
#include <vector>
#include <boost/math/special_functions/bessel.hpp>
#include <boost/math/special_functions/gamma.hpp>

using namespace Rcpp;
using namespace arma;
//[[Rcpp::depends(RcppArmadillo)]]
//[[Rcpp::depends(BH)]]



//' Isotropic Matern covariance function
//'
//' From a matrix of locations and covariance parameters of the form
//' (variance, range, smoothness, nugget), return the square matrix of
//' all pairwise covariances.
//' @param locs A matrix with \code{n} rows and \code{d} columns.
//' Each row of locs gives a point in R^d.
//' @param covparms A vector with covariance parameters
//' in the form (variance, range, smoothness, nugget)
//' @return A matrix with \code{n} rows and \code{n} columns, with the i,j entry
//' containing the covariance between observations at \code{locs[i,]} and
//' \code{locs[j,]}.
//' @section Parameterization:
//' The covariance parameter vector is (variance, range, smoothness, nugget)
//' = \eqn{(\sigma^2,\alpha,\nu,\tau^2)}, and the covariance function is parameterized
//' as
//' \deqn{ M(x,y) = \sigma^2 2^{1-\nu}/\Gamma(\nu) (|| x - y ||/\alpha )^\nu K_\nu(|| x - y ||/\alpha ) }
//' The nugget value \eqn{ \sigma^2 \tau^2 } is added to the diagonal of the covariance matrix.
//' NOTE: the nugget is \eqn{ \sigma^2 \tau^2 }, not \eqn{ \tau^2 }. 
// [[Rcpp::export]]
arma::mat matern_isotropic2(arma::vec covparms, arma::mat locs1, arma::mat locs2 ){

    // fail-safe to prevent large smoothness values
    covparms(2) = std::min( covparms(2), 8.0 );
	
    int dim = locs1.n_cols;
    int n1 = locs1.n_rows;
    int n2 = locs2.n_rows;
    //double nugget = covparms( 0 )*covparms( 3 );
    double nugget = 0.0; // sets nugget to zero!
    double normcon = covparms(0)/(pow(2.0,covparms(2)-1.0)*boost::math::tgamma(covparms(2) ));
	
    // calculate covariances
    arma::mat covmat(n1,n2);

    for(int i1 = 0; i1 < n1; i1++){
        for(int i2 = 0; i2 < n2; i2++){
            
            // calculate distance
            double d = 0.0;
            for(int j=0; j<dim; j++){
                d += pow( ( locs1(i1,j) - locs2(i2,j) )/covparms(1), 2.0 );
            }
            d = pow( d, 0.5 );
            
	    // calculate covariance
            if( d == 0.0 ){
                covmat(i1,i2) = covparms(0);
            } else {
                covmat(i1,i2) = normcon*pow(d,covparms(2))*boost::math::cyl_bessel_k(covparms(2),d);
            }
        }    
    }
    return covmat;
}



//' @describeIn matern_isotropic2 Derivatives of isotropic Matern covariance
// [[Rcpp::export]]
arma::cube d_matern_isotropic2(arma::vec covparms, arma::mat locs1, arma::mat locs2 ){

    // fail-safe to prevent large smoothness values
    covparms(2) = std::min( covparms(2), 8.0 );
	
    int dim = locs1.n_cols;
    int n1 = locs1.n_rows;
    int n2 = locs2.n_rows;
    //double nugget = covparms( 0 )*covparms( 3 );
    double nugget = 0.0; // sets nugget to zero!
    // normcon does not include covparms(0), because sometimes covparms(0) is 0.
    double normcon = 1.0/(pow(2.0,covparms(2)-1.0)*boost::math::tgamma(covparms(2) ));
    double eps = 1e-8;
    double normconeps = 
        1.0/(pow(2.0,covparms(2)+eps-1.0)*boost::math::tgamma(covparms(2)+eps ));
    
    // calculate derivatives
    arma::cube dcovmat = arma::cube(n1,n2,covparms.n_elem, fill::zeros);
    for(int i1=0; i1<n1; i1++){ for(int i2=0; i2<n2; i2++){

        double d = 0.0;
        for(int j=0; j<dim; j++){
            d += pow( ( locs1(i1,j) - locs2(i2,j) )/covparms(1), 2.0 );
        }
        d = pow( d, 0.5 );
        
        double cov;        
        if( d == 0.0 ){
            cov = covparms(0);
            dcovmat(i1,i2,0) += 1.0;
            dcovmat(i1,i2,1) += 0.0;
            dcovmat(i1,i2,2) += 0.0;
        } else {
            cov = covparms(0)*normcon*pow( d, covparms(2) )*boost::math::cyl_bessel_k(covparms(2), d);
            // variance parameter
            dcovmat(i1,i2,0) += normcon*pow(d,covparms(2))*boost::math::cyl_bessel_k(covparms(2),d);
            // range parameter
            dcovmat(i1,i2,1) += covparms(0)*normcon*pow(d,covparms(2))*
                boost::math::cyl_bessel_k(covparms(2)-1.0, d)*d/covparms(1);
            // smoothness parameter (finite differencing)
            dcovmat(i1,i2,2) += (
	        covparms(0)*normconeps*pow(d,covparms(2)+eps)*boost::math::cyl_bessel_k(covparms(2) + eps, d) - cov)/eps;
        }
    }}
    return dcovmat;
}


#endif
