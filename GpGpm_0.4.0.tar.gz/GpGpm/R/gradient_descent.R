
#' Gradient Descent Algorithm
#' 
#' @param likfun likelihood function, returns likelihood, gradient, and hessian
#' @param start_parms starting values of parameters
#' @param link link function for parameters (used for printing)
#' @param silent TRUE/FALSE for suppressing output
#' @param convtol convergence tolerance on step dot grad
#' @param max_iter maximum number of Fisher scoring iterations
gradient_descent <- function(likfun, start_parms, link, silent=FALSE, convtol=1e-4, max_iter=40 ){
    
    # evaluate function at initial values
    logparms <- start_parms
    #print(logparms)
    likobj <- likfun(logparms)

    # test likelihood object    
    if( !test_likelihood_object(likobj) ){
        stop("Invalid Starting values")
        logparms <- 0.1*logparms
        likobj <- likfun(logparms)
    }

    # assign loglik, grad, and info
    loglik <- likobj$loglik        
    grad <- likobj$grad
    info <- likobj$info

    for(j in 1:max_iter){

        # keep track of x1, x2, x3 and y1, y2, y3.
        # these are positions and values of most recently evaluated points.
        # initial points
        x0 <- 0
        y0 <- likobj$loglik
    
        # initial value of stepsize
        stepfac <- 0.5/max(diag(info))

        # proposed step gets a 0 suffix
        # accepted step has no suffix

        # evaluate the objective function
        step0 <- -stepfac*grad
        likobj0 <- likfun( logparms + step0 )
        #print(likobj0$loglik)
        
        # if the loglik goes up, decrease the stepfac until loglik goes down
        no_decrease <- FALSE
        while( likobj$loglik > loglik ){
            stepfac <- 0.5*stepfac
            step0 <- -stepfac*grad
            likobj0 <- likfun( logparms + step0 )
            #print(likobj0$loglik)
            if( stepfac < 1e-6 ){
                no_decrease <- TRUE
                break
            }
        }

        if( !no_decrease ){

            step <- step0
            likobj <- likobj0
            absgrad <- sqrt( sum( likobj$grad^2 ) )

            # points for first step
            x1 <- stepfac
            y1 <- likobj$loglik

            mult <- 1.3
            max_steps <- 7


            for(k in 1:max_steps){

                stepfac <- mult*stepfac
                step0 <- -stepfac*grad

                likobj0 <- likfun(logparms + step0 )
                absgrad0 <- sqrt( sum( likobj0$grad^2 ) )
                #print(-likobj0$loglik)

                x2 <- stepfac
                y2 <- likobj0$loglik

                # keep going if the new loglik is lower
                #if( likobj0$loglik < likobj$loglik ){
                if( likobj0$loglik < likobj$loglik ){

                    absgrad <- absgrad0
                    step <- step0
                    likobj <- likobj0
                
                    # update the values
                    x0 <- x1
                    y0 <- y1
                    x1 <- x2
                    y1 <- y2
                
                # break if it got higher
                } else {
                    break
                }
                
            }

            # solve for quadratic coefficients, calculate minimum position of quadratic
            X <- cbind( rep(1,3), c(x0,x1,x2), c(x0^2,x1^2,x2^2) )
            y <- c(y0,y1,y2)
            b <- solve(X,y)
            stepfac <- -b[2]/(2*b[3])

            # propose this as the step, calculate loglik
            step0 <- -stepfac*grad
            likobj0 <- likfun( logparms + step0 )
            
            # right now, likobj$loglik is y1. switch to likobj0 only if better than y1
            if( likobj0$loglik < likobj$loglik ){
                step <- step0
                likobj <- likobj0
            }
            # otherwise, do not change

            stepgrad <- sum( step*grad )

            # redefine logparms, loglik, grad, info
            logparms <- logparms + step
            loglik <- likobj$loglik        
            grad <- likobj$grad
            info <- likobj$info

            # print some stuff out
            if(!silent){
                cat(paste0("Iter ",j,": \n"))
                cat("pars = ",  paste0(round(link(logparms),4)), "  \n" )
                cat(paste0("loglik = ", round(-loglik,6),         "  \n"))
                cat("grad = ")
                cat(as.character(round(grad,4)),"\n")
                cat("step dot grad = ",stepgrad,"\n")
                cat("\n")
            }

        }
        
        # if gradient is small, then break and return the results        
        if( abs(stepgrad) < convtol || no_decrease ){
            break
        }
    }

    # collect information to return
    betahatinfo <- likobj        
    betahat <- as.vector(betahatinfo$betahat)
    betacov <- solve(betahatinfo$betainfo)
    sebeta <- sqrt(diag(betacov))
    tbeta <- betahat/sebeta

    ret <- list(
        covparms = link(logparms), 
        logparms = logparms,
        betahat = betahat, 
        sebeta = sebeta,
        betacov = betacov,
        tbeta = tbeta,
        loglik = loglik,
        no_decrease = no_decrease,
        grad = likobj$grad,
        info = likobj$info,
        conv = ( abs(stepgrad) < convtol || no_decrease )
    )
    return(ret)

}
