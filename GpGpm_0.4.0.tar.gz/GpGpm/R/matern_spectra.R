

# two-dimensional matern spectrum
matern_spectrum <- function( covparms, omega ){

    sig <- covparms[1]
    range <- covparms[2]
    smooth <- covparms[3]
    omegasq <- omega[,1]^2 + omega[,2]^2

    spec <- sig*2*sqrt(pi)*smooth*range^(-2*smooth)*( range^(-2) + 4*pi^2*omegasq )^(-smooth-1)
    return(spec)

}

d_matern_spectrum <- function( covparms, omega ){

    sig <- covparms[1]
    range <- covparms[2]
    smooth <- covparms[3]
    omegasq <- omega[,1]^2 + omega[,2]^2
    M <- range^(-2) + 4*pi^2*omegasq

    spec <- matern_spectrum( covparms, omega )
    d_spec <- matrix(NA, length(spec), length(covparms) )

    d_spec[,1] <- 2*sqrt(pi)*smooth*range^(-2*smooth)*M^(-smooth-1)
    d_spec[,2] <- spec*( -2*smooth/range + 1/M*(smooth+1)*2/range^3 )
    d_spec[,3] <- spec*( 1/smooth - log(range^2) - log(M) )
    
    return(d_spec)

}

dd_matern_spectrum <- function( covparms, omega ){

    sig <- covparms[1]
    range <- covparms[2]
    smooth <- covparms[3]
    omegasq <- omega[,1]^2 + omega[,2]^2
    M <- range^(-2) + 4*pi^2*omegasq

    spec <- matern_spectrum( covparms, omega )
    d_spec <- d_matern_spectrum( covparms, omega )
    dd_spec <- array(NA, c(length(spec), length(covparms), length(covparms) ) )

    dd_spec[,1,1] <- 0

    dd_spec[,1,2] <- d_spec[,1]*(-2*smooth)/range + d_spec[,1]*M^(-1)*(smooth+1)*(2/range^3)
    dd_spec[,2,1] <- dd_spec[,1,2]

    dd_spec[,1,3] <- d_spec[,1]*( 1/smooth - 2*log(range) - log(M) )
    dd_spec[,3,1] <- dd_spec[,1,3]

    dd_spec[,2,2] <- d_spec[,2]*( -2*smooth/range + (smooth+1)*2/range^3/M ) + 
                     spec*( (smooth+1)*4/range^6/M^2 - (smooth+1)*6/range^4/M + 2*smooth/range^2 )
    
    dd_spec[,2,3] <- d_spec[,3]*( -2*smooth/range + M^(-1)*(smooth+1)*2/range^3 ) +
                     spec*( -2/range + M^(-1)*2/range^3 )
    dd_spec[,3,2] <- dd_spec[,2,3]

    dd_spec[,3,3] <- d_spec[,3]*( 1/smooth - 2*log(range) - log(M) ) - spec/smooth^2

    return( dd_spec )
}



matern_cross_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
    #omega <- omega[-1,]
    
    cross_spec <- array( NA, c(nrow(omega), ncomp, ncomp ) )
    for(j1 in 1:ncomp){
        for(j2 in 1:j1){
            these_parms <- c( pmat$variance[j1,j2], pmat$range[j1,j2], pmat$smoothness[j1,j2] )
            cross_spec[,j1,j2] <- matern_spectrum( these_parms, omega ) 
            if( j1 != j2 ){ cross_spec[,j2,j1] <- cross_spec[,j1,j2] }
        }
    }

    return(cross_spec)
}

matern_marg_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    marg_spec <- array( NA, c(nrow(omega), ncomp ) )
    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        marg_spec[,j1] <- matern_spectrum( these_parms, omega ) 
    }

    return(marg_spec)
}

matern_marg_spectra2 <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    marg_spec <- array( 0, c(nrow(omega), ncomp, ncomp ) )
    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        marg_spec[,j1,j1] <- matern_spectrum( these_parms, omega ) 
    }

    return(marg_spec)
}

matern_marg_spectra2 <- function( covparms, effrange, nomega = 40 ){
    # gives result as diagonal cross spectra

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
    #omega <- omega[-1,]
    
    cross_spec <- array( 0, c(nrow(omega), ncomp, ncomp ) )
    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        cross_spec[,j1,j1] <- matern_spectrum( these_parms, omega ) 
    }

    return(cross_spec)
}

d_matern_cross_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    d_cross_spec <- array( 0, c(nrow(omega), ncomp, ncomp, nparms) )

    for(j1 in 1:ncomp){
        for(j2 in 1:j1){
            these_parms <- c( pmat$variance[j1,j2], pmat$range[j1,j2], pmat$smoothness[j1,j2] )
            ind <- multi_matern_parm_index( ncomp, j1, j2 )
            d_spec <- d_matern_spectrum( these_parms, omega )
            # assumes parameters in ind are ordered "variance", "range", "smoothness"
            for(k in 1:3){
                d_cross_spec[, j1, j2, ind[[k]] ] <- d_spec[,k]
                if( j1 != j2 ){
                    d_cross_spec[, j2, j1, ind[[k]] ] <- d_cross_spec[, j1, j2, ind[[k]] ]
                }
            }
        }
    }
    return(d_cross_spec)
}


d_matern_marg_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    d_marg_spec <- array( 0, c(nrow(omega), ncomp, nparms) )

    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        ind <- multi_matern_parm_index( ncomp, j1, j1 )
        d_spec <- d_matern_spectrum( these_parms, omega )
        # assumes parameters in ind are ordered "variance", "range", "smoothness"
        for(k in 1:3){
            d_marg_spec[, j1, ind[[k]] ] <- d_spec[,k]
        }
    }
    return(d_marg_spec)
}


d_matern_marg_spectra2 <- function( covparms, effrange, nomega = 40 ){
    # gives result as diagonal cross spectra

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    d_cross_spec <- array( 0, c(nrow(omega), ncomp, ncomp, nparms) )

    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        ind <- multi_matern_parm_index( ncomp, j1, j1 )
        d_spec <- d_matern_spectrum( these_parms, omega )
        # assumes parameters in ind are ordered "variance", "range", "smoothness"
        for(k in 1:3){
            d_cross_spec[, j1, j1, ind[[k]] ] <- d_spec[,k]
        }
    }
    return(d_cross_spec)
}


dd_matern_cross_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    dd_cross_spec <- array( 0, c(nrow(omega), ncomp, ncomp, nparms, nparms) )

    for(j1 in 1:ncomp){
        for(j2 in 1:j1){
            these_parms <- c( pmat$variance[j1,j2], pmat$range[j1,j2], pmat$smoothness[j1,j2] )
            ind <- multi_matern_parm_index( ncomp, j1, j2 )
            dd_spec <- dd_matern_spectrum( these_parms, omega )
            # assumes parameters in ind are ordered "variance", "range", "smoothness"
            for(k1 in 1:3){
                for(k2 in 1:3){
                    dd_cross_spec[, j1, j2, ind[[k1]], ind[[k2]] ] <- dd_spec[,k1,k2]
                    dd_cross_spec[, j2, j1, ind[[k1]], ind[[k2]] ] <- dd_spec[,k1,k2]
                }
            }
        }
    }
    return(dd_cross_spec)
}


dd_matern_marg_spectra <- function( covparms, effrange, nomega = 40 ){

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    dd_marg_spec <- array( 0, c(nrow(omega), ncomp, nparms, nparms) )

    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        ind <- multi_matern_parm_index( ncomp, j1, j1 )
        dd_spec <- dd_matern_spectrum( these_parms, omega )
        # assumes parameters in ind are ordered "variance", "range", "smoothness"
        for(k1 in 1:3){
            for(k2 in 1:3){
                dd_marg_spec[, j1, ind[[k1]], ind[[k2]] ] <- dd_spec[,k1,k2]
            }
        }
    }
    return(dd_marg_spec)
}

dd_matern_marg_spectra2 <- function( covparms, effrange, nomega = 40 ){
    # gives result as diagonal cross spectra

    # get parameter matrices
    pmat <- multi_parms_mat( covparms )
    ncomp <- nrow( pmat$variance )
    nparms <- length(covparms)

    omega1 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega2 <- seq(0,4/(2*pi*effrange),length.out = nomega)
    omega <- expand.grid( omega1, omega2 )
#    omega <- omega[-1,]
    
    dd_cross_spec <- array( 0, c(nrow(omega), ncomp, ncomp, nparms, nparms) )

    for(j1 in 1:ncomp){
        these_parms <- c( pmat$variance[j1,j1], pmat$range[j1,j1], pmat$smoothness[j1,j1] )
        ind <- multi_matern_parm_index( ncomp, j1, j1 )
        dd_spec <- dd_matern_spectrum( these_parms, omega )
        # assumes parameters in ind are ordered "variance", "range", "smoothness"
        for(k1 in 1:3){
            for(k2 in 1:3){
                dd_cross_spec[, j1, j1, ind[[k1]], ind[[k2]] ] <- dd_spec[,k1,k2]
            }
        }
    }
    return(dd_cross_spec)
}

